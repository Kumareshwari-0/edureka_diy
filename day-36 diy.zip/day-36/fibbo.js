function fibboseries(num){
    if(num<2){
        return num;
    }
    else{
        return fibboseries(num-1)+fibboseries(num-2);
    }
}

let n=Number(prompt('Enter positive number:'));
if(n==1){
    console.log(1,2);
}
else{
    for(let i=0;i<n;i++){
        console.log(`${fibboseries(i)}`);
    }
}