let http=require("http")
let url=require("url")

let server=http.createServer((req,res)=>{
    let parse=url.parse(req.url,true)
    if(parse.pathname==="/"){
        res.writeHead(200,{"content-type": "text/html"})
        res.end(`<h1>This is home page</h1>`)
    }
    else if(parse.pathname==="/contact"){
        res.writeHead(200,{"content-type":"text/html"})
        res.end(`<h1>this is contact page</h1>`)
    }
    else if(parse.pathname==="/filter"){
        res.writeHead(200,{"content-type":"text/html"})
        res.end(`<h1>this is filter page</h1>`)
    }
    else if(parse.pathname==="/details"){
        res.writeHead(200,{"content-type":"text/html"})
        res.end(`<h1>this is details page</h1>`)
    }
    else{
        res.end(`<h1>this is 404 error</h1>`)
    }
})
server.listen("3000",()=>{
    console.log("server running on http://localhost:3000");
})