export default [
    { label: "Bangalore" },
    { label: "Coimbatore" },
    { label: "chennai" },
    { label: "Salem" },
    { label: "Tirunelveli" },
    { label: "Trichy" },
    { label: "Erode" }
];